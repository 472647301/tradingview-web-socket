interface IUtilsMap<T> {
  [key: string]: T;
}
